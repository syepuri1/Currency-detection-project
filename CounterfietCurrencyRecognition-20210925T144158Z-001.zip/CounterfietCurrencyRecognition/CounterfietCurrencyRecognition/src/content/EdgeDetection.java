package content;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.Math;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class EdgeDetection {

    // (Level Evolution) code repeated from Contour file
    public static final double PI = Math.PI;
    public static final int RED = 0;

    // NEW
    public static final int UPPER = 0;
    public static final int CENTER = 1;
    public static final int LOWER = 2;
    public static final int[] scales = new int[]{3};

    // test code
    public void debugger() {
        calculateDIForImage(new File("circle"), true);
        calculateDIHatForImage("circle");
    }

    // Level Evolution to path
    public void calculateDIHatForImage(String imageName) {
        for (int i = 0; i < scales.length; i++) {
            int scale = scales[i];
            for (int j = 0; j < 4; j++) {
                double theta = (-1.0 / 2.0) * PI + ((1.0 / 4.0) * PI) * j;
                int k = 4 + j; // opposite angle, 4 should be angles.legnth/2

                try {
                    BufferedImage firstImage = ImageIO.read(new File(Source.storage, imageName + "_" + i + "_" + j + ".jpg"));
                    BufferedImage secondImage = ImageIO.read(new File(Source.storage, imageName + "_" + i + "_" + k + ".jpg"));

                    BufferedImage newImage = new BufferedImage(firstImage.getWidth(), firstImage.getHeight(), BufferedImage.TYPE_INT_RGB);

                    int oax1 = 0;
                    int oay1 = 0;
                    Graphics2D g2dd = newImage.createGraphics();
                    BasicStroke bsd = new BasicStroke(2);
                    g2dd.setStroke(bsd);
                    g2dd.setColor(Color.BLACK);

                    for (int x = 0; x < firstImage.getWidth(); x++) {
                        for (int y = 0; y < firstImage.getHeight(); y++) {
                            Point p = new Point(x, y);
                            int c = (getPixelRGB(firstImage, p)[0] - getPixelRGB(secondImage, p)[0]) / 2 + 128;
                            //System.out.println(x+","+y+","+c);
                            //helias
                            if (c > 100 && c < 180) {
                                newImage.setRGB(x, y, (new Color(c, c, c)).hashCode());
                            } else {
                                newImage.setRGB(x, y, (new Color(0, 0, 0)).hashCode());
                                if (oax1 == 0 && oay1 == 0) {
                                    oax1 = x;
                                    oay1 = y;
                                } else {
                                    double dist = Math.sqrt(Math.pow((oax1 - x), 2) + Math.pow((oay1 - y), 2));
                                    //newImage.setRGB(ax, ay, (Color.red).hashCode());
                                    if (dist < 15) {
                                        g2dd.drawLine(oax1, oay1, x, y);
                                    }
                                    oax1 = x;
                                    oay1 = y;
                                }
                            }
                        }
                    }

//                    if (Source.properImage() && Source.finalWindow == 3) {
//                        Source.finalWindow++;
//
//                        Graphics2D g2d = newImage.createGraphics();
//                        BasicStroke bs = new BasicStroke(2);
//                        g2d.setStroke(bs);
//                        g2d.setColor(Color.BLACK);
//                        String parts[] = Source.dataLine.split("-");
//                        for (int a = 3; a < parts.length; a++) {
//                            if (a == 3) {
//                                String d = parts[a];
//                                int ax = Integer.parseInt(d.split(",")[0]);
//                                int ay = Integer.parseInt(d.split(",")[1]);
//                                //newImage.setRGB(ax, ay, (Color.red).hashCode());
//                                g2d.drawOval(ax, ay, 1, 1);
//                            } else {
//                                String od = parts[a - 1];
//                                String d = parts[a];
//
//                                int oax = Integer.parseInt(od.split(",")[0]);
//                                int oay = Integer.parseInt(od.split(",")[1]);
//
//                                int ax = Integer.parseInt(d.split(",")[0]);
//                                int ay = Integer.parseInt(d.split(",")[1]);
//
//                                double dist = Math.sqrt(Math.pow((ax - oax), 2) + Math.pow((ay - oay), 2));
//                                //System.out.println("------------------"+dist);
//
//                                //newImage.setRGB(ax, ay, (Color.red).hashCode());
//                                if (dist < 15) {
//                                    g2d.drawLine(oax, oay, ax, ay);
//                                }
//                                g2d.drawOval(ax, ay, 1, 1);
//                            }
//                        }
//                        Source.finalWindow = 0;
//                    }
                    // save images after you are done
                    File file = new File(Source.storage, imageName + "_" + j + ".jpg");
                    //File file = new File(imageName+"_"+i+"_"+j+"_di.jpg");
                    file.createNewFile();
                    ImageIO.write(newImage, "jpg", file);

                    try {
                        if (Source.view != null) {
                            Source.view.dispose();
                        }
                        Viewer_1 obj = new Viewer_1();
                        obj.setTitle("Edges : " + file.getName());
                        obj.setVisible(true);
                        Source.finalWindow++;
                        obj.Open(file.getAbsolutePath());
                        Source.view = obj;
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                } catch (IOException io) {
                    io.printStackTrace();
                }
            }
        }
    }

    // Level Evolution to path
    public void calculateDIForImage(File f, boolean diAvgAlgo) {
        BufferedImage image = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
        try {
            image = ImageIO.read(f);
        } catch (IOException io) {
            io.printStackTrace();
        }

        for (int i = 0; i < scales.length; i++) {
            int scale = scales[i];
            for (int j = 0; j < 8; j++) {
                BufferedImage newImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
                double theta = (-1.0 / 2.0) * PI + ((1.0 / 4.0) * PI) * j;

                System.out.println(theta);
                for (int x = scale; x < image.getWidth() - scale; x++) {
                    for (int y = scale; y < image.getHeight() - scale; y++) {
                        ArrayList<Point> q = diAvgAlgo ? getPointsWithPositionDIHat(new Point(x, y), theta, scale)
                                : getPointsWithPosition(new Point(x, y), theta, scale);
                        int sum = 0;
                        for (Point p : q) {
                            sum += getPixelRGB(image, p)[RED];
                        }
                        int avg = sum / q.size();
                        newImage.setRGB(x, y, (new Color(avg, avg, avg).hashCode()));
                    }
                }

                // save images after you are done
                try {
                    String imageName = f.getName(); // Level Evolution
                    imageName = imageName.substring(0, imageName.length() - 4);

                    File file = new File(Source.storage, imageName + "_" + i + "_" + j + ".jpg");
                    file.createNewFile();
                    ImageIO.write(newImage, "jpg", file);

                    try {
                        Viewer_1 obj = new Viewer_1();
                        obj.setTitle("Contour : " + file.getName());
                        //obj.setVisible(true);
                        //obj.Open(file.getAbsolutePath());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                } catch (IOException io) {
                    io.printStackTrace();
                }
            }
        }
    }

    // Level Evolution
    public ArrayList<Point> getPointsWithPositionDIHat(Point p, double theta, int scale) {
        Point u = nextPointWithPointAndAngle(p, theta, UPPER);
        Point c = nextPointWithPointAndAngle(p, theta);
        Point l = nextPointWithPointAndAngle(p, theta, LOWER);

        ArrayList<Point> points = new ArrayList<Point>();
        points.addAll(getPointsWithPosition(u, theta, scale));
        points.addAll(getPointsWithPosition(c, theta, scale));
        points.addAll(getPointsWithPosition(l, theta, scale));

        // append extra point at center
        points.add(getPointByAngleAndScale(p, theta, scale + 1));

        return points;
    }

    public ArrayList<Point> getPointsWithPosition(Point p, double theta, int scale) {
        ArrayList<Point> points = new ArrayList<Point>();

        // lookup table would be more efficient here, if scale is 5, then take the calculation
        // from scale of 3 and append 2 pixels to it, etc. (Level Evolution)
        for (int i = 0; i < scale; i++) {
            points.add(p);
            p = nextPointWithPointAndAngle(p, theta);
        }

        return points;
    }

    public Point nextPointWithPointAndAngle(Point p, double theta) {
        return nextPointWithPointAndAngle(p, theta, CENTER);
    }

    // Level Evolution?
    public Point getPointByAngleAndScale(Point p, double theta, int scale) {
        int dx = (int) Math.round(Math.cos(theta));
        int dy = (int) Math.round(Math.sin(theta));

        return new Point(p.x + (dx * 3), p.y + (dy * 3));
    }

    public Point nextPointWithPointAndAngle(Point p, double theta, int direction) {
        int dx = (int) Math.round(Math.cos(theta));
        int dy = (int) Math.round(Math.sin(theta));

        switch (direction) {
            case UPPER:
                return new Point(p.x + dy, p.y - dx);
            case CENTER:
                return new Point(p.x + dx, p.y + dy);
            case LOWER:
                return new Point(p.x - dy, p.y + dx);
        }
        return p; // should never reach
    }

    public int[] getPixelRGB(BufferedImage img, Point p) {
        int[] rgb;

        switch (img.getType()) {
            case BufferedImage.TYPE_BYTE_GRAY:
                int gray = img.getRaster().getSample(p.x, p.y, 0);
                rgb = new int[]{gray, gray, gray};
                break;

            case BufferedImage.TYPE_USHORT_GRAY:
                gray = img.getRaster().getSample(p.x, p.y, 0) / 257;
                rgb = new int[]{gray, gray, gray};
                break;

            default:
                int argb = img.getRGB(p.x, p.y);
                rgb = new int[]{
                    (argb >> 16) & 0xff,
                    (argb >> 8) & 0xff,
                    (argb) & 0xff
                };
                break;
        }

        return rgb;
    }

}
