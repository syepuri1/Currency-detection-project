package content;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

public class DViewer extends JFrame {

    private JMenuBar menubar;
    private JMenu mFile;

    private JMenuItem mIExit;
    private JMenuItem mIAbout;

    private JScrollPane sPPicture;
    private JLabel lPicture;

    int width = 0;
    int height = 0;

    public String fname = null;

    private void init() {
        menubar = new JMenuBar();
        mFile = new JMenu("File");
        
        mIExit = new JMenuItem("Exit");
        mIAbout = new JMenuItem("Details");

        menubar.add(mFile);

        mFile.add(mIAbout);
        mFile.add(mIExit);

        setJMenuBar(menubar);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
        setSize(width + 200, height + 20);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Container show = getContentPane();
        show.add(lPicture);

        sPPicture = new JScrollPane();
        sPPicture.getViewport().add(lPicture);
        getContentPane().add(BorderLayout.CENTER, sPPicture);

        mIExit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                Exit();
            }
        });

        mIAbout.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                About();
            }
        });

    }

    public DViewer(String path, String title, String fname) {
        super(title);
        lPicture = new JLabel();
        Open(path);
        this.fname = fname;
        init();
    }

    private JFileChooser fC = new JFileChooser();
    int w, h;
    Image image;
    File f;

    private void Open() {
        if (fC.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {

            ImageIcon image = new ImageIcon(fC.getSelectedFile().getAbsolutePath());
            lPicture.setIcon(image);

        }
    }

    public void Open(String path) {
        try {
            ImageIcon image = new ImageIcon(path);
            lPicture.setIcon(image);

            BufferedImage bimg = ImageIO.read(new File(path));
            width = bimg.getWidth();
            height = bimg.getHeight();
        } catch (IOException ex) {
            Logger.getLogger(DViewer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void setFullScreen(final JFrame frame) {
        frame.dispose();
        frame.setResizable(true);
        frame.setUndecorated(true);
        frame.setLocation(0, 0);
        frame.setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
        frame.setVisible(true);
        frame.repaint();

        frame.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ev) {
                frame.setVisible(false);
                //System.exit(0);
            }
        });
    }

    public void FullScreen(Graphics g) throws IOException {
        Open();

        menubar.setVisible(false);
        //setFullScreen(Semestr2.this);
        w = this.getWidth();
        h = this.getHeight();
        f = new File(fC.getSelectedFile().getAbsolutePath());
        image = ImageIO.read(f);

        if (image != null) {
            g.drawImage(image, w / 2 - image.getWidth(this) / 2, h / 2 - image.getHeight(this) / 2, this);
        }

    }

    private void Exit() {
        System.exit(0);
    }

    private void About() {
        System.out.println("===========ggggggggg=");
        String parts[] = this.fname.split("-");
        System.out.println("===========ggggggggg=");
        
    }

}
