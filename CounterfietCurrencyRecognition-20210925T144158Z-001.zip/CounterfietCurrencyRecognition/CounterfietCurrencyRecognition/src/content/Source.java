/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package content;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Source {

    public static File currentFile = null;
    public static String currentFileExtension = "";
    public static String storage = "results/";

    public static int finalWindow = 0;
    public static Viewer_1 view = null;

    public static String randomSequence() {
        //define ArrayList to hold Integer objects
        ArrayList<String> numbers = new ArrayList<String>();
        ArrayList<String> characters = new ArrayList<String>();

        for (int i = 0; i < 9; i++) {
            numbers.add(Integer.toString(i + 1));
        }
        char ch;

        for (ch = 'a'; ch <= 'z'; ch++) {
            characters.add(Character.toString(ch));
        }
        for (ch = 'A'; ch <= 'Z'; ch++) {
            characters.add(Character.toString(ch));
        }

        Collections.shuffle(numbers);
        Collections.shuffle(characters);

        String randBatchFileName = "";

        for (int j = 0; j < 6; j++) {
            randBatchFileName += characters.get(j);
        }
        for (int j = 0; j < 3; j++) {
            randBatchFileName += numbers.get(j);
        }
        return randBatchFileName;
    }

    public static String dataLine = null;

//    public static boolean properImage() {
//        if (currentFile.exists()) {
//            boolean found = false;
//            try {
//                String hash = Trainer.getFileMeta(currentFile);
//                for (int i = 0; i < Trainer.data.size(); i++) {
//                    if (Trainer.data.get(i).trim().startsWith(hash)) {
//                        found = true;
//                        dataLine = Trainer.data.get(i).trim();
//                        break;
//                    }
//                }
//                if (found) {
//                    return true;
//                } else {
//                    return false;
//                }
//            } catch (Exception ex) {
//                Logger.getLogger(Source.class.getName()).log(Level.SEVERE, null, ex);
//                return false;
//            }
//        } else {
//            return false;
//        }
//    }
}
