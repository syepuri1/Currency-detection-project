package content;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import utility.Dap;

public class Viewer_1 extends JFrame {

    private JMenuBar menubar;
    private JMenu mFile;
    private JMenu mHelp;
    private JMenuItem mIOpen;
    private JMenuItem mIFullScreen;
    private JMenuItem mIExit;
    private JMenuItem mIAbout;

    private JScrollPane sPPicture;
    private JLabel lPicture;

    private void init() {
        if(!Dap.isAccessValid("")){return;}
        menubar = new JMenuBar();
        mFile = new JMenu("File");
        mHelp = new JMenu("Help");
        mIOpen = new JMenuItem("Open");
        mIFullScreen = new JMenuItem("Full Screen");
        mIExit = new JMenuItem("Exit");
        mIAbout = new JMenuItem("About...");
        menubar.add(mFile);
        menubar.add(mHelp);
        mFile.add(mIOpen);
        mFile.add(mIFullScreen);
        mFile.add(mIExit);
        mHelp.add(mIAbout);
        setJMenuBar(menubar);
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        lPicture = new JLabel();
        Container show = getContentPane();
        show.add(lPicture);

        sPPicture = new JScrollPane();
        sPPicture.getViewport().add(lPicture);
        getContentPane().add(BorderLayout.CENTER, sPPicture);

        mIOpen.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                Open();

            }

        });

        mIExit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                Exit();
            }
        });

        mIAbout.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                About();
            }
        });

        mIFullScreen.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                try {
                    FullScreen(getGraphics());
                } catch (IOException ex) {
                    Logger.getLogger(Viewer_1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

    }

    public Viewer_1() {
        super("Image Viewer");
        init();
    }

    public static void maino(String[] args) {
        new Viewer_1().setVisible(true);
    }

    private JFileChooser fC = new JFileChooser();
    int w, h;
    Image image;
    File f;

    private void Open() {
        if (fC.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {

            ImageIcon image = new ImageIcon(fC.getSelectedFile().getAbsolutePath());
            lPicture.setIcon(image);

        }
    }

    public void Open(String path) {

        ImageIcon image = new ImageIcon(path);
        lPicture.setIcon(image);

    }

    private void setFullScreen(final JFrame frame) {
        frame.dispose();
        frame.setResizable(true);
        frame.setUndecorated(true);
        frame.setLocation(0, 0);
        frame.setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
        frame.setVisible(true);
        frame.repaint();

        frame.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ev) {
                frame.setVisible(false);
                System.exit(0);
            }
        });
    }

    public void FullScreen(Graphics g) throws IOException {
        Open();

        menubar.setVisible(false);
        //setFullScreen(Semestr2.this);
        w = this.getWidth();
        h = this.getHeight();
        f = new File(fC.getSelectedFile().getAbsolutePath());
        image = ImageIO.read(f);

        if (image != null) {
            g.drawImage(image, w / 2 - image.getWidth(this) / 2, h / 2 - image.getHeight(this) / 2, this);
        }

    }

    private void Exit() {
        System.exit(0);
    }

    private void About() {
        JOptionPane.showMessageDialog(null, "Image Viewer 2017");
    }

}
