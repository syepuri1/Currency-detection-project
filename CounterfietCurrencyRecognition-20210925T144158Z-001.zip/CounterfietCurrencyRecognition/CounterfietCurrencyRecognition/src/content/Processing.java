/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package content;

/**
 *
 * @author 108
 */
import alg.ImageComparator;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.swing.JOptionPane;
import ui.Config;

public class Processing {

    final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();

    public static void getColourValue(File file) throws Exception {
        ImageInputStream is = ImageIO.createImageInputStream(file);
        Iterator iter = ImageIO.getImageReaders(is);

        if (!iter.hasNext()) {
            System.out.println("Cannot load the specified file " + file.getAbsolutePath());
            System.exit(1);
        }
        ImageReader imageReader = (ImageReader) iter.next();
        imageReader.setInput(is);

        BufferedImage image = imageReader.read(0);

        int height = image.getHeight();
        int width = image.getWidth();

        Map m = new HashMap();
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                int rgb = image.getRGB(i, j);
                int[] rgbArr = getRGBArr(rgb);
                // Filter out grays....                
                if (!isGray(rgbArr)) {
                    Integer counter = (Integer) m.get(rgb);
                    if (counter == null) {
                        counter = 0;
                    }
                    counter++;
                    m.put(rgb, counter);
                }
            }
        }
        String colourHex = getMostCommonColour(m, file);
        //System.out.println(colourHex);        
    }

    public static String getMostCommonColour(Map map, File file) {
        List list = new LinkedList(map.entrySet());
        Collections.sort(list, new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o1)).getValue())
                        .compareTo(((Map.Entry) (o2)).getValue());
            }
        });
        Map.Entry me = (Map.Entry) list.get(list.size() - 1);
        Map.Entry me2 = (Map.Entry) list.get(list.size() - 2);
        Map.Entry me3 = (Map.Entry) list.get(list.size() - 3);

        //System.out.println("-----------"+me.getKey());
        //System.out.println("-----------"+me2.getKey());
        //System.out.println("-----------"+me3.getKey());
        int[] rgb = getRGBArr((Integer) me.getKey());
        int[] rgb2 = getRGBArr((Integer) me2.getKey());
        int[] rgb3 = getRGBArr((Integer) me3.getKey());

        /*
         return Integer.toHexString(rgb[0]) + " " + Integer.toHexString(rgb[1]) + " " + Integer.toHexString(rgb[2])+
         "-"+Integer.toHexString(rgb2[0]) + " " + Integer.toHexString(rgb2[1]) + " " + Integer.toHexString(rgb2[2])+
         "-"+Integer.toHexString(rgb3[0]) + " " + Integer.toHexString(rgb3[1]) + " " + Integer.toHexString(rgb3[2]);
         */
        Color top = new Color(rgb[0], rgb[1], rgb[2]);
        Color sec = new Color(rgb2[0], rgb2[1], rgb2[2]);
        Color tri = new Color(rgb3[0], rgb3[1], rgb3[2]);

        Segments obj = new Segments(file.getName(), top, sec, tri, file);
        Segments.data.add(obj);
        System.out.print(".");
        return (rgb[0]) + " " + (rgb[1]) + " " + (rgb[2])
                + "-" + (rgb2[0]) + " " + (rgb2[1]) + " " + (rgb2[2])
                + "-" + (rgb3[0]) + " " + (rgb3[1]) + " " + (rgb3[2]);
    }

    public static Segments getColourValueSpecific(File file) throws Exception {
        ImageInputStream is = ImageIO.createImageInputStream(file);
        Iterator iter = ImageIO.getImageReaders(is);

        if (!iter.hasNext()) {
            System.out.println("Cannot load the specified file " + file.getAbsolutePath());
            System.exit(1);
        }
        ImageReader imageReader = (ImageReader) iter.next();
        imageReader.setInput(is);

        BufferedImage image = imageReader.read(0);

        int height = image.getHeight();
        int width = image.getWidth();

        Map m = new HashMap();
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                int rgb = image.getRGB(i, j);
                int[] rgbArr = getRGBArr(rgb);
                // Filter out grays....                
                if (!isGray(rgbArr)) {
                    Integer counter = (Integer) m.get(rgb);
                    if (counter == null) {
                        counter = 0;
                    }
                    counter++;
                    m.put(rgb, counter);
                }
            }
        }
        return getMostCommonColourSpecific(m, file);
    }

    public static Segments getMostCommonColourSpecific(Map map, File file) {
        List list = new LinkedList(map.entrySet());
        Collections.sort(list, new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o1)).getValue())
                        .compareTo(((Map.Entry) (o2)).getValue());
            }
        });
        Map.Entry me = (Map.Entry) list.get(list.size() - 1);
        Map.Entry me2 = (Map.Entry) list.get(list.size() - 2);
        Map.Entry me3 = (Map.Entry) list.get(list.size() - 3);

        //System.out.println("-----------"+me.getKey());
        //System.out.println("-----------"+me2.getKey());
        //System.out.println("-----------"+me3.getKey());
        int[] rgb = getRGBArr((Integer) me.getKey());
        int[] rgb2 = getRGBArr((Integer) me2.getKey());
        int[] rgb3 = getRGBArr((Integer) me3.getKey());

        /*
         return Integer.toHexString(rgb[0]) + " " + Integer.toHexString(rgb[1]) + " " + Integer.toHexString(rgb[2])+
         "-"+Integer.toHexString(rgb2[0]) + " " + Integer.toHexString(rgb2[1]) + " " + Integer.toHexString(rgb2[2])+
         "-"+Integer.toHexString(rgb3[0]) + " " + Integer.toHexString(rgb3[1]) + " " + Integer.toHexString(rgb3[2]);
         */
        Color top = new Color(rgb[0], rgb[1], rgb[2]);
        Color sec = new Color(rgb2[0], rgb2[1], rgb2[2]);
        Color tri = new Color(rgb3[0], rgb3[1], rgb3[2]);

        Segments obj = new Segments(file.getName(), top, sec, tri, file);
        System.out.println("Processing Complete");
        return obj;
    }

    public static int[] getRGBArr(int pixel) {
        int alpha = (pixel >> 24) & 0xff;
        int red = (pixel >> 16) & 0xff;
        int green = (pixel >> 8) & 0xff;
        int blue = (pixel) & 0xff;
        return new int[]{red, green, blue};

    }

    public static boolean isGray(int[] rgbArr) {
        int rgDiff = rgbArr[0] - rgbArr[1];
        int rbDiff = rgbArr[0] - rgbArr[2];
        // Filter out black, white and grays...... (tolerance within 10 pixels)
        int tolerance = 10;
        if (rgDiff > tolerance || rgDiff < -tolerance) {
            if (rbDiff > tolerance || rbDiff < -tolerance) {
                return false;
            }
        }
        return true;
    }

    public static void mainz(String... a) throws Exception {
        if (!Config.training) {
            Segments.data.clear();
        }

        File f = new File(Config.trainingSet);
        File l[] = f.listFiles();

        for (int i = 0; i < l.length && (!Config.training); i++) {
            getColourValue(l[i]);
        }
        Config.training = true;

        File toCheck = new File(Config.testImage);
        Segments obj = getColourValueSpecific(toCheck);

        int foundValues = 0;
        for (int i = 0; i < Segments.data.size(); i++) {
            String f1 = Segments.data.get(i).getFileName();
            String f2 = toCheck.getName();
            Color tc1 = Segments.data.get(i).getDomColor();
            Color tc2 = obj.getDomColor();
            if (tc1.equals(tc2)) {
                foundValues++;

                //System.out.println("DUP Files : " + f1 + "," + f2);
                Color c = Segments.data.get(i).getSecColor();
                Color d = obj.getSecColor();
                double secDistance = (c.getRed() - d.getRed()) * (c.getRed() - d.getRed()) + (c.getGreen() - d.getGreen()) * (c.getGreen() - d.getGreen()) + (c.getBlue() - d.getBlue()) * (c.getBlue() - d.getBlue());
                //System.out.println("----Secondary Distance-----" + secDistance);

                c = Segments.data.get(i).getTernaryColor();
                d = obj.getTernaryColor();
                double triDistance = (c.getRed() - d.getRed()) * (c.getRed() - d.getRed()) + (c.getGreen() - d.getGreen()) * (c.getGreen() - d.getGreen()) + (c.getBlue() - d.getBlue()) * (c.getBlue() - d.getBlue());
                //System.out.println("----Ternary Distance-----" + triDistance);

                BufferedImage baseImage = ImageIO.read(Segments.data.get(i).getFile());
                BufferedImage baseImageSame = ImageIO.read(obj.getFile());
                ImageComparator comp = new ImageComparator(baseImage, baseImageSame);
                //System.out.println("--comp---" + comp.getPixelDiffCount() + "----" + comp.getPixelDiffPercent());
                String iType = "normal";
                if (Segments.data.get(i).getFileName().contains("fake")) {
                    iType = "Counterfiet Currency Detected...";
                }
                if (Segments.data.get(i).getFileName().contains("genuine")) {
                    iType = "Genuine Currency Detected...";
                }
                DViewer probable = new DViewer(toCheck.getAbsolutePath(), iType, f1);
                probable.setVisible(true);
            }

        }
        if (foundValues == 0) {
            JOptionPane.showMessageDialog(null, "Found No Currency Images Matching\nwith the selected Curreny Image");
            return;
        } else {
            //Viewer ori = new Viewer(toCheck.getAbsolutePath(), "Selected Currency Image");
            //ori.setVisible(true);
        }

    }
}
