/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package content;

import java.awt.Color;
import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author Helias
 */
public class Segments {
    
    public static ArrayList<Segments> data = new ArrayList<Segments>();
    
    public String fileName;
    public Color domColor;
    public Color secColor;
    public Color ternaryColor;
    public File file;

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }
    
    

    public Segments(String fileName, Color domColor, Color secColor, Color ternaryColor,File file) {
        this.fileName = fileName;
        this.domColor = domColor;
        this.secColor = secColor;
        this.ternaryColor = ternaryColor;
        this.file = file;
    }

    
    
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Color getDomColor() {
        return domColor;
    }

    public void setDomColor(Color domColor) {
        this.domColor = domColor;
    }

    public Color getSecColor() {
        return secColor;
    }

    public void setSecColor(Color secColor) {
        this.secColor = secColor;
    }

    public Color getTernaryColor() {
        return ternaryColor;
    }

    public void setTernaryColor(Color ternaryColor) {
        this.ternaryColor = ternaryColor;
    }
    
    
    
}
