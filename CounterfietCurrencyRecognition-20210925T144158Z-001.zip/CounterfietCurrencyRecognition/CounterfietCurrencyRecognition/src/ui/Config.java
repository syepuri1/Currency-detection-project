package ui;

import java.io.File;
import java.util.ArrayList;
import javax.swing.JFrame;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Helias
 */
public class Config {   
    public static String trainingSet = "nbproject/db";
    public static String testDir = "scans";
    public static String testImage = "";

    public static int imageWidth = 480;
    public static int imageHeight = 640;
    public static String projectTitle = "Counter Fit Currency Detection";
    
    public static boolean training = false;   

    public static ArrayList<File> listf(String directoryName, ArrayList<File> files) {
        File directory = new File(directoryName);

        // get all the files from a directory
        File[] fList = directory.listFiles();
        for (File file : fList) {
            if (file.isFile()) {
                files.add(file);
            } else if (file.isDirectory()) {
                listf(file.getAbsolutePath(), files);
            }
        }
        
        return files;
    }
    
    public static JFrame frame = null;
}
